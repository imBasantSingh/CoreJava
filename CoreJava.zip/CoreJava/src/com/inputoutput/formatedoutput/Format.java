package com.inputoutput.formatedoutput;
//Formating the output
public class Format {
    public static void main(String args[]){
    	
    	int a = 1, b=2,c=3,d=4;
    	
    	System.out.print(a+"\t"+b);
    	System.out.println(b+"\n"+b);
    	System.out.print(":"+c);
    	System.out.println();//This throw cursor to new line
    	System.out.println("Hello\\Hi\""+d);
    	
    	System.out.println("*****************************");
    	
    	System.out.println("lfello ");
    	System.out.println("\\Hello\\") ;
    	System.out.println("\"Hello\":,");
    	
    }
}
