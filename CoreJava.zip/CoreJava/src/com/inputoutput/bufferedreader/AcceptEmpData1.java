package com.inputoutput.bufferedreader;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class AcceptEmpData1 {
    public static void main(String args[]) throws IOException {
        //Create a bufferedReader Object to accept data from keyword
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        //Ask for Employee Data and read it
        System.out.println("Enter the Employee ID : ");
        int emp_id = Integer.parseInt(br.readLine());
        System.out.println("Enter the sex(M/F) : ");
        char sex = br.readLine().charAt(0);
        //Alternate solution
        //br.skip(2);
        System.out.println("Enter the name : ");
        String name = br.readLine();

        //Display Emp Data
        System.out.println("Employ ID is : " + emp_id);
        System.out.println("Employ sex is : " + sex);
        System.out.println("Employ Name is : " + name);
    }

}
