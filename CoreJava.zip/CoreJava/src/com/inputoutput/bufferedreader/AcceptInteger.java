package com.inputoutput.bufferedreader;

import java.io.*;

public class AcceptInteger {
    public static void main(String args[]) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
//Ask for integer and read it
        System.out.println("Enter the integer : ");
        int num = Integer.parseInt(br.readLine());
        System.out.println("Integer you have entered is " + num);
    }
}
