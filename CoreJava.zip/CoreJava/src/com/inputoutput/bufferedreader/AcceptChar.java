/* Accepting a single character from Keyboard */
package com.inputoutput.bufferedreader;

import java.io.*;

public class AcceptChar {
    public static void main(String args[]) throws IOException {
        //Create a bufferedReader Object to accept data from keyword
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        //Ask for char and read it
        System.out.print(" Enter the character ");
        char ch1 = (char) br.read();

        //Display the char
        System.out.println("You have entered " + ch1);
    }
}
