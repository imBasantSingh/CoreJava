//To test if number is positive or negative. 
package com.controlstatements.selectionstatements;

public class DemoIfElse {
	public static void main(String args[])
	{
		int num = 0 ;
		if(num < 0)
		System.out.println(num+ " is negative number");
		else if(num > 0)
		System.out.println(num+ " is positive number");
		else
		System.out.println(num+ " is Zero");
			
	}

}
