package com.controlstatements.selectionstatements;

public class DemoSwitch {
	public static void main(String args[]){
		char color = 'g'; //Color is set to g
		
		switch(color){
		case 'r' : 
			System.out.println("Color is Red");
		case 'g' : 
			System.out.println("Color is Green");
		case 'b' : 
			System.out.println("Color is Blue");
		case 'w' : 
			System.out.println("Color is White");
		default : 
			System.out.println("Color is Not known");
		}
	}

}
