package com.controlstatements.Iterativestatements;

public class DemoForLoop2 {
	public static void main(String args[]){
		int x = 1;
		for( ; ; ){
			System.out.print(x+"\t");
			x++;
			if(x > 10 ) 
				break ; //If x values exceeds 10, then comes out of the loop
		}
	}

}
