package com.controlstatements.Iterativestatements;

public class DemoWhile {
     public static void main(String args[]){
    	 int x = 1;
    	 while(x <= 10){
    		 System.out.print(x+"\t");
    		 x++ ;
    	 }
     }
}
