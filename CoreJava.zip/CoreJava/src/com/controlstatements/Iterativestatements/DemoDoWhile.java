//To display number from 1 to 10
package com.controlstatements.Iterativestatements;

public class DemoDoWhile {
	public static void main(String args[]){
		int x = 1; //Initialize number with 1
		do{
			System.out.print(x+"\t");
			x++;
			}while(x<=10);
		}

}
