package com.controlstatements.JumpStatements;

public class DemoBreak {
	public static void main(String args[]){
		boolean x = true ;
		
		bl1: {
			bl2: {
			bl3: {
			System.out.println("Block3");
			if(x)
				break bl2; //goto end of bl2
		} //end of bl3
		System.out.println("Block2"); 
		} //end of Block2
		System.out.println("Block1"); 
		} //end of Block3
		System.out.println("Out of all block"); 
		}
			
	}



