package com.collections.arraylist.examples;

/*
 * void trimToSize():
		This method decreases the size of arraylist to its actual size.
		This method helps in saving extra memory allocated at start, and ultimately increases 
		the performance.

 * */
import java.util.ArrayList;

public class ArrayListTrimToSize {
	public static void main(String args[]) {
		ArrayList<Integer> aList = new ArrayList<Integer>(10);
		// use add() method to add elements in the list
		aList.add(1);
		aList.add(2);
		aList.add(3);
		aList.add(4);
		
		// Trimming the Array List
		aList.trimToSize();
		System.out.println("Printing an ArrayList after using trimToSize method "+aList);
		}
}
