package com.collections.arraylist.examples;

/*
 * boolean add(Object o):
		It adds an element of Specific Object type at the end of Arraylist as no index is
		mentioned in method.
		It returns True if element is successfully added, and returns false if it is not.
 * */

import java.util.ArrayList;

public class ArrayListAdd {
	public static void main(String[] args) {
		//Integer ArrayList
		ArrayList<Integer> aList = new ArrayList<Integer>();
		aList.add(5);
		aList.add(11);
		aList.add(17);
		System.out.println("Integer Number Added in ArrayList= " + aList);
		//String ArrayList
		ArrayList<String> sList = new ArrayList<String>();
		sList.add("Learning");
		sList.add("JAVA");
		System.out.println("String Added in ArrayList= "+ sList);
		}
}





