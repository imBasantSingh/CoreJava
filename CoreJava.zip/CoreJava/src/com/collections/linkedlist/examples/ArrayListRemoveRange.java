package com.collections.linkedlist.examples;

/*
 * protected void removeRange(int first, int last):
		It deletes the group of elements from the first to last as mentioned in the argument.
		It includes the first index and excludes the last index.
 * */

import java.util.ArrayList;

public class ArrayListRemoveRange{
	public static void main(String[] args) {
		ArrayList<Integer> aList = new ArrayList<Integer>();
		aList.add(3);
		aList.add(5);
		aList.add(9);
		aList.add(11);
		aList.add(15);
		aList.add(16);
		System.out.println("The Arraylist:" + aList);
		
		// using removerange() method to remove value of index 1 to index 2
		//aList.removeRange(1,3);
		System.out.println("Removing Element From Index 1 to Index 2 using removeRange(1,3)");
		System.out.println("The Arraylist after using removeRange:" + aList);
		}
}
