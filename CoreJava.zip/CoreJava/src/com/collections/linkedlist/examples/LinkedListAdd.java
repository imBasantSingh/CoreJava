package com.collections.linkedlist.examples;

/*
 * boolean add(Object o):
		It adds an element of Specific Object type at the end of LinkedList as no index is
		mentioned in method.
		It returns True if element is successfully added, and returns false if it is not.
 * */

import java.util.LinkedList;

public class LinkedListAdd {
	public static void main(String[] args) {
		//Integer ArrayList
		LinkedList<Integer> lList = new LinkedList<Integer>();
		lList.add(5);
		lList.add(11);
		lList.add(17);
		System.out.println("Integer Number Added in ArrayList= " + lList);
		//String ArrayList
		LinkedList<String> sList = new LinkedList<String>();
		sList.add("Learning");
		sList.add("JAVA");
		System.out.println("String Added in ArrayList= "+ sList);
		}
}





