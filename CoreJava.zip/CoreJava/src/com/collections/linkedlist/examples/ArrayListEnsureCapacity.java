package com.collections.linkedlist.examples;

/*
 * void ensureCapacity(int minCapacity):
		This method ensures that the size of arraylist is not less than mentioned in the argument list, if it is less then it increases its size up to
        as mentioned in the argument of this method.
 * */

import java.util.ArrayList;

public class ArrayListEnsureCapacity {
	public static void main(String args[]) {
		ArrayList<Integer> aList = new ArrayList<Integer>(3);
		// use add() method to add elements in the list
		aList.add(5);
		aList.add(2);
		aList.add(9);
		//this method will increase the capacity to 20
		aList.ensureCapacity(20);
		System.out.println("Array List Number = " + aList);
		
		//Size will remain same as total number of elements.
		System.out.println("Size of aList  = " + aList.size());
		}
}





