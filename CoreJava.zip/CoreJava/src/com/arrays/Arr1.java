package com.arrays;

public class Arr1 {
public static void main(String args[]){
	//Creating a 1D array
	int arr[] = {34,23,45,67,78};
		
	//Displaying the element of the array
	System.out.println("Value of Arrays are ");
	for (int i=0;i<5;i++){
		System.out.println(arr[i]);
	}
  }
}

