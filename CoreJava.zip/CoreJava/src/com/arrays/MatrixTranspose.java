//program which accepts elements of a matrix and displaying its transpose
package com.arrays;

import java.io.*;

public class MatrixTranspose {
public static void main(String args[]) throws IOException {
	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

	System.out.println("Enter number of rows : ");
	int r = Integer.parseInt(br.readLine());
	
	System.out.println("Enter number of column : ");
	 int c = Integer.parseInt(br.readLine());
	 
	 int Matrix[][] = new int[r][c];
	 for(int i=0;i<r;i++){
		 for(int j=0;j<c;j++){
			 System.out.println("Enter numbers: ");
			 Matrix[i][j] = Integer.parseInt(br.readLine()); 
		 }
	 }
	 for(int i=0;i<r;i++){
		 for(int j=0;j<c;j++){
			 System.out.print(Matrix[i][j]+"  "); 
		 }
		 System.out.println();
	 }
	 
	 System.out.println("Transpose of the matrix is: ");
	 
	 for(int i=0;i<c;i++){
		 for(int j=0;j<r;j++){
			 System.out.print(Matrix[j][i]+"  "); 
		 }
		 System.out.println();
	 }
}
}
