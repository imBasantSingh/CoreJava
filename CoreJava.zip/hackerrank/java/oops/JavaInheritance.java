package com.hackerrank.java.oops;

/**
 * Created by IntelliJ IDEA.
 *
 * @author rampatra
 * @since 7/19/15
 * @time: 3:36 PM
 */
public class JavaInheritance {

    public void JavaInheritance() {

    }

    public static void main(String[] args) {

    }
}


class Arithmetic {

}

class Adder extends Arithmetic {
    int add(int a, int b) {
        return a + b;
    }
}
