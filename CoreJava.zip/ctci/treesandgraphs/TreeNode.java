package com.ctci.treesandgraphs;

/**
 * @author rampatra
 * @since 2019-02-15
 */
public class TreeNode {
    public int val;
    public TreeNode left;
    public TreeNode right;
    
    public TreeNode(int val) {
        this.val = val;
    }
}
