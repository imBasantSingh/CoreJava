package module1;

/*
When learning a new language, we first learn to output some message. 
Here, we'll start with the famous Hello World message. Now, here you are given a function to complete. 
Don't worry about the ins and outs of functions, just add the command 
(System.out.print("Hello World")) to print Hello World.

Input Format :
No input

Output format :
Hello World

User Task:
Your task is to complete the function below to print hello world.

Explanation:
Hello World is printed.

For More Input/Output Examples Use 'Expected Output' option **
 * */


	//Initial Template for Java
	//Position this line where user code will be pasted.
	class Gfg1{
	    
	    public static void main(String args[]){
	        
	        Geeks g = new Geeks();
	        
	        g.printHello();
	    }
	    
	}
	
	/*This is a function problem.You only need to complete the function given below*/
	//User function Template for Java
	class Geeks{
	    
	    // Function to print hello
	    static void printHello(){
	        
	        // Your code here
	    	System.out.println("Hello World");
	        
	    }
}