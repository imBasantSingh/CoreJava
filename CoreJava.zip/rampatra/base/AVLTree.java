package com.rampatra.base;

/**
 * Created by IntelliJ IDEA.
 *
 * @author rampatra
 * @since 4/25/15
 * @time: 10:25 AM
 */
public class AVLTree<E extends Comparable<E>> extends Tree<E> {

}
